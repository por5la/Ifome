import React, { useContext, useState, useEffect } from 'react';
import { View, Text, FlatList, Image, Pressable  } from 'react-native';
import { CarrinhoContext } from '../contexts/context';
import estilo from './estilos';
import { useNavigation } from '@react-navigation/native';

export default function Carrinho() {
  const { itensCarrinho, limparCarrinho } = useContext(CarrinhoContext);
  const [total, setTotal] = useState(0);
  const navigation = useNavigation();

  useEffect(() => {
    let novoTotal = 0;
    itensCarrinho.map((item) => {
      novoTotal += item.preco;
    });

    setTotal(novoTotal);
  },[itensCarrinho]);

  const finalizar = () => {
    limparCarrinho();
    navigation.navigate('iFome');
    alert('Pedido finalizado com sucesso')
  }
  return (
    <View style={estilo.conteinerView}>
      <FlatList
        data={itensCarrinho}
        renderItem={({ item }) => (
          <View style={estilo.conteinerDescricao}>
            <Image style={estilo.imgLanche} source={{ uri: item.imagem }} />
            <View style={estilo.textoLista}>
              <Text style={estilo.titulo}>{item.titulo}</Text>
              <Text style={estilo.descricao}>{item.descricao}</Text>
              <Text style={estilo.titulo}>
                {item.preco.toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </Text>
            </View>
          </View>
        )}
      />
      <View style={estilo.container}>
        <Text style={estilo.titulo}>
          {total.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL',
          })}
        </Text>
        <Pressable onPress={finalizar}>
          <Text style={estilo.botao}>Finalizar</Text>
        </Pressable>
      </View>
    </View>
  );
}
