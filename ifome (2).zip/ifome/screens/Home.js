import React, { useContext } from 'react';
import { View, Text, FlatList, Image, Pressable, Button } from 'react-native';
import estilo from './estilos';
import Icon from 'react-native-vector-icons/FontAwesome';
import { CarrinhoContext } from '../contexts/context';

const pratos = [
  {
    titulo: 'Hambúrguer',
    descricao: 'Feito com amor',
    imagem:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjEahxVeHGzdFSjglrL6QRY_ng-DUuLtjR-Q&usqp=CAU',
    preco: Number(29.99),
  },
  {
    titulo: 'Shawarma',
    descricao: 'Tipo Árabe',
    imagem:
      'https://static.itdg.com.br/images/1200-630/b6eb66220ea1853b98a09bb0c96f06c4/242117-original.jpg',
    preco: Number(22.49),
  },
  {
    titulo: 'Hot Dog',
    descricao: 'Tipo americano',
    imagem:
      'https://img.freepik.com/fotos-gratis/cachorro-quente-de-carne-grelhada-com-lanche-de-ketchup-ia-generativa_188544-7829.jpg',
    preco: Number(17.99),
  },
];

export default function Home({ navigation }) {
  const { adicionarCarrinho } = useContext(CarrinhoContext);

  const listaCarrinho = (prato) => {
    adicionarCarrinho(prato);
  };

  return (
    <View style={estilo.conteinerView}>
      <View style={estilo.botaCarrinho}>
        <Pressable>
          <Icon
            name="shopping-cart"
            size={30}
            style={estilo.carrinho}
            onPress={() => navigation.navigate('Carrinho')}
          />
        </Pressable>
      </View>
      <FlatList
        data={pratos}
        renderItem={({ item }) => (
          <View style={estilo.conteinerDescricao}>
            <Image style={estilo.imgLanche} source={{ uri: item.imagem }} />
            <View style={estilo.textoLista}>
              <Text style={estilo.titulo}>{item.titulo}</Text>
              <Text style={estilo.descricao}>{item.descricao}</Text>
              <Text style={estilo.titulo}>
                {item.preco.toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </Text>
              <Pressable onPress={() => listaCarrinho(item)}>
                <Text style={estilo.botao}>Comprar</Text>
              </Pressable>
            </View>
          </View>
        )}
      />
      <View style={estilo.container}>
        <Pressable onPress={() => navigation.navigate('Carrinho')}>
          <Text style={estilo.botao}>Comprar</Text>
        </Pressable>
      </View>
    </View>
  );
}
