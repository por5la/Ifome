import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './screens/Home';
import Carrinho from './screens/Carrinho';
import { CartProvider } from './contexts/context';

const Stack = createStackNavigator();

const barra = {
  headerStyle: {
    backgroundColor: 'red',
  },
  headerTintColor: '#f2f5f7',
};

function App() {
  return (
    <CartProvider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="iFome" component={Home} options={barra}/>
          <Stack.Screen name="Carrinho" component={Carrinho} options={barra}/>
        </Stack.Navigator>
      </NavigationContainer>
    </CartProvider>
  );
}
export default App;
