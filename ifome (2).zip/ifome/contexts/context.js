import React, { createContext, useState } from 'react';

export const CarrinhoContext = createContext([]);

export const CartProvider = ({ children }) => {
  const [itensCarrinho, setItensCarrinho] = useState([]);

  const adicionarCarrinho = (produto) => {
    setItensCarrinho((prevItems) => [...prevItems, produto]);
  };

  const limparCarrinho = () => {
    setItensCarrinho([]);
  };

  return (
    <CarrinhoContext.Provider value={{ itensCarrinho, adicionarCarrinho, limparCarrinho }}>
      {children}
    </CarrinhoContext.Provider>
  );
};
